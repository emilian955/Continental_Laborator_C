#include <stdio.h>
#include "Header.h"
#include <stdlib.h>
#define EX 1

int main() {
#if EX==1
	union SIU a;
	set(&a);
	print(&a);
	printf("Variabila a: %d ", a.SIU_PCR);
#endif
#if EX==2

	struct point Punct;
	init(&Punct);
	afisareStare(&Punct);

	struct point Points[5];
	for (int i = 0; i < 5; i++)
	{
		int j = 5;
		while (j) {
			parcurgere(&Points[10]);
			afisareStare(&Points[10]);
			j--;
		}
		printf("Aici s-a terminat punctul %d \n", i);
	}

#endif
#if EX==3
	struct parametru Param[5];
	init1(&Param);
	afisareParam(&Param);

	printf("\n\n\nDupa sortare\n\n\n");
	//swap1(&Param[0], &Param[1]);
	//bubbleSort(&Param);
	bubbleSortval(&Param);
	afisareParam(&Param);
#endif
}