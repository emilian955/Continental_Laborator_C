#include "Header.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#pragma warning(disable:4996)
void set(union SIU* a) {
	a->b.DSC = 3;
	a->b.HYS = 0;
	a->b.ODE = 0;
	a->b.WPE = 1;
	a->b.WPS = 1;
	//create(&a);
}
void printk(union SIU* a) {
	printf("DSC: %d ", a->b.DSC);
	printf("\n");
	printf("HYS: %d ", a->b.HYS);
	printf("\n");
	printf("ODE: %d", a->b.ODE);
	printf("\n");
	printf("WPE: %d ", a->b.WPE);
	printf("\n");
	printf("WPS: %d ", a->b.WPS);

}
int create(union SIU* a) {
	int s = 0;
	a->SIU_PCR = a->SIU_PCR | (a->b.DSC << 6);
	a->SIU_PCR = a->SIU_PCR | (a->b.HYS << 4);
	a->SIU_PCR = a->SIU_PCR | (a->b.ODE << 5);
	a->SIU_PCR = a->SIU_PCR | (a->b.WPS);
	a->SIU_PCR = a->SIU_PCR | (a->b.WPE << 1);
	return s;

}








void calculareStare(struct point* Punct) {
	int in, out;

	if (Punct->Current == Normal) {
		if (Punct->In == 1 && Punct->Out == 0) {
			Punct->Current = Scurt_Circuit_Baterie;
		}
		if (Punct->In == 0 && Punct->Out == 1) {
			Punct->Current = Scurt_Circuit_Masa;
		}
	}
	else{
	if (Punct->Current == Scurt_Circuit_Masa) {
		if (Punct->In == 1 && Punct->Out == 1) {
			Punct->Current = Normal;
		}
		if (Punct->In == 1 && Punct->Out == 0) {
			Punct->Current = Scurt_Circuit_Baterie;
		}
	}else
		if (Punct->Current == Scurt_Circuit_Baterie) {
			if (Punct->In == 0&& Punct->Out == 1) {
				Punct->Current = Scurt_Circuit_Masa;
			}
			if (Punct->In == 0 && Punct->Out == 0) {
				Punct->Current =  Normal;
			}
		}
	}
}
void parcurgere(struct point* Punct) {
	Punct->In = rand() % 2;
	Punct->Out = rand() % 2;
	calculareStare(Punct);
}
void init(struct point* Punct) {
	Punct->In = 0;
	Punct->Out = 0;
	Punct->Current = Normal;
}
void afisareStare(struct point* Punct) {
	int i;
	printf("In: %d\n", Punct->In);
	printf("Out: %d\n", Punct->Out);
	printf("State: %d\n", Punct->Current);
	printf("\n");
	
}





void init1(struct parametru* Param) {

	char str[13] = { 'P','a','r','a','m','_'};
	
	for (int i = 0; i < 5; i++) {
		int tip = rand() % 4;
		Param[i].valoare.BOOL = 0;
		Param[i].valoare.UINT8 = 0;
		Param[i].valoare.UINT16 = 0;
		Param[i].valoare.UINT32 = 0;
		char ch;
		ch = i + '0';
		*Param[i].nume_parametru = (char*)malloc(13);
		str[6] = ch;
		strcpy_s(Param[i].nume_parametru,sizeof(Param[i].nume_parametru), str);
		if (tip == 1) {
			Param[i].tip = BOOL;
			Param[i].valoare.BOOL = rand() % 2;
		}
		if (tip == 2) {
			Param[i].tip = UINT8;
			Param[i].valoare.UINT8 = rand() % 256;
		}
		if (tip == 3) {
			Param[i].tip = UINT16;
			Param[i].valoare.UINT16 = rand() % 65535;
		}
		if (tip == 4) {
			Param[i].tip = UINT32;
			Param[i].valoare.UINT32 = rand() % 42949672;
		}
	}
	
}
void afisareParam(struct parametru* Param) {
	int i;
	for(i = 0; i <= 4;i++){
	printf("Nume: %s\n", Param[i].nume_parametru);
	printf("Tip: %d\n", Param[i].tip);
	if(Param[i].tip==BOOL)
		printf("BOOL: %d\n", Param[i].valoare.BOOL);
	if (Param[i].tip == UINT8)
		printf("UINT8: %d\n", Param[i].valoare.UINT8);
	if (Param[i].tip == UINT16)
		printf("UINT16: %d\n", Param[i].valoare.UINT16);
	if (Param[i].tip == UINT32)
		printf("UINT32: %d\n", Param[i].valoare.UINT32);
	printf("\n");
	}
}

void swap1(struct parametru* Param1, struct parametru* Param2) {
	struct parametru aux1;
	struct parametru* aux=&aux1;
	*aux = *Param1;
	*Param1 = *Param2;
	*Param2 = *aux;


}
void bubbleSort(struct parametru* Param)
{
	int i, j;
	for (i = 0; i < 5; i++)
	// Last i elements are already in place  
		for (j = 0; j < 5 - i - 1; j++)
			if (Param[j].tip > Param[j + 1].tip)
			{
				swap1(&Param[j], &Param[j + 1]);
			}

}
void bubbleSortval(struct parametru* Param)
{
	int i, j;
	for (i = 0; i < 5; i++)
		// Last i elements are already in place  
		for (j = 0; j < 5 - i - 1; j++)
			if (Param[j].valoare.UINT32 > Param[j + 1].valoare.UINT32)
			{
				swap1(&Param[j], &Param[j + 1]);
			}

}