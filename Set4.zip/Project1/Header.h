#pragma once
struct SIU1 {
	unsigned int DSC : 2;
	unsigned int ODE : 1;
	unsigned int HYS : 1;
	unsigned int : 0;
	unsigned int WPE : 1;
	unsigned int WPS : 1;
};
union SIU {
	unsigned char SIU_PCR;
	struct SIU1 b;

};

enum Stare { Normal, Scurt_Circuit_Masa, Scurt_Circuit_Baterie};

 enum type{ UINT8 , UINT16, UINT32, BOOL};
struct point {
	unsigned char In;
	unsigned char Out;
	enum Stare Current;
};
typedef union  {
	unsigned int UINT32 : 32;
	unsigned short UINT16 : 16;
	unsigned char UINT8 : 8;
	unsigned char BOOL : 1;
}VALUE;

struct parametru {
	char nume_parametru[20];
	VALUE valoare;
	enum type tip;

};



void set(union SIU* a);
void printk(union SIU* a);
int create(union SIU* a);
void init(struct point* Punct);
void afisareStare(struct point* Punct);
void calculareStare(struct point* Punct);
void parcurgere(struct point* Punct);
void init1(struct parametru* Param);
void afisareParam(struct parametru* Param);
void swap1(struct parametru* Param1, struct parametru* Param2);
void bubbleSort(struct parametru* Param);
void bubbleSortval(struct parametru* Param);