#pragma once
#include <stdio.h>
#ifndef Bit_Operation_H_
#define Bit_Operation_H_
void ex1(int n);
int ex2();
int get(unsigned char c, int poz);
int set(unsigned char c, int poz, int bit);
int rightrot(unsigned char a, int n);
void ex9();
void ex11();
void ex10();
void ex10_1();
#endif // !Bit_Operation_H_