#include <stdio.h>
#include "Bit_Operation.h"
extern int k = 10;
char z = 0;
void ex1(int n) {
    //unsigned i;
   // for (i = 1 << 7; i > 0; i = i / 2)
    //    (n & i) ? printf("1") : printf("0");
    if (n > 1)
        ex1(n / 2);
    printf("%d", n % 2);
}
int ex2() {
    z=!z;//!b
    printf("%u", z);
    printf("\n");
    return z;
}


int get(unsigned char c, int poz) {
    c >>= poz;
    if (c & 1)
    {
        printf("%d", 1);
    }
    else
        printf("%d", 0);
}

int set(unsigned char c, int poz, int bit) {
    unsigned char mask = 1 << poz;
    if (bit == 0) {
        mask = ~mask;
        c = c & mask;
    }
    else
        c = c | mask;
    printf("%u", c);

}
int rightrot(unsigned char a, int n) {
    unsigned char mask;
    while (n) {
        if (a & 1) {
            mask = 1 << 7;
        }
        else
        {
            mask = 0 << 7;
        }
        n--;
        a >>= 1;
        a = a | mask;
    }

    printf("%u", a);
}





void ex9() {
    unsigned char a = 255;
    printf("%u\n", a);//0-255

    char b = 127;
    printf("%d\n", b);

    short c = 32767;//trece la -32767
    printf("%hd\n", c);
    //unsigned 65,535


    long d = 2147483647;
    printf("%li\n", d);
    //unsigned 4,294,967,295
}
void ex10() {
    int static x=20;
    x+=1;
    printf("%d\n", x);
    
}
void ex10_1() {
    extern int k;
    printf("%d\n", k);
    
}
void ex11() {
    unsigned char a;
    signed char b, c;
    b = 10;
    c = 0;
    a = 255;
    c = ~a - b++;//256-10
    printf("%d\n", c);

}