#include <stdio.h>

#include "Bit_Operation.h"
#include "File1.h"

#define MACRO 1
#define SET(PIN,N) (PIN |=  (1<<N))
#define CLR(PIN,N) (PIN &= ~(1<<N))


unsigned char b = 189;
unsigned char c = 3;
extern int y=10;
extern unsigned long EBI_MCR = 0xC3F84000;
extern unsigned short EMIOS_CCR = 0xFFFF;
void main() {
#if MACRO==1
    ex1(3);
    printf("\n");
#endif

#if MACRO==2

    ex2();
    ex2();
    ex2();
#endif
#if MACRO==3
    get(6, 2);
    printf("\n");
    set(6, 2,0);
#endif
#if MACRO==4
    rightrot(13, 3);

#endif
#if MACRO==5

    setSIZE(0, 0);
    getSIZE();
    setDBM(1);
    getDBM();
#endif
#if MACRO==9
    ex9();


#endif
#if MACRO==11
    ex11();


#endif
#if MACRO==10

    ex10_1();

#endif
}
//0000 0011
//1100 0000
