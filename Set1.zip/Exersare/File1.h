#pragma once
#include <stdio.h>
#ifndef FILE1_H
#define FILE1_H
void ex10_2();
void getDBM();
void setDBM(int bit);
void getSIZE();
void getEARP();
void getIF();
void setSIZE(int bit,int bit1);
void setIF(int bit, int bit1, int bit2, int bit3);
#endif 