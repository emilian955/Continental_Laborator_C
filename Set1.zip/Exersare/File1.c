#include <stdio.h>
#include "File1.h"
void ex10_2() {
	extern int k;
	printf("%d", k);
}
extern unsigned long EBI_MCR;
extern unsigned short EMIOS_CCR;

void getDBM() {
    unsigned long copy = EBI_MCR;
    if (copy & 1)
    {
        printf("%d\n", 1);
    }
    else
        printf("%d\n", 0);
}
int getMDIS() {
    unsigned long copy = EBI_MCR;
    copy >>= 6;
    if (copy & 1)
    {
        printf("%d", 1);
    }
    else
        printf("%d", 0);
}

void getSIZE() {
    unsigned long copy = EBI_MCR;
    copy >>= 24;
    int ultimul;
    if (copy & 1)
    {
        ultimul = 1;
    }
    else
        ultimul = 0;
    copy >>=1;
    if (copy & 1)
    {
        printf("%d", 1);
    }
    else
        printf("%d", 0);
    printf("%d\n", ultimul);
}
void getEARP() {
    unsigned long copy = EBI_MCR;
    copy >>= 11;
    int ultimul;
    if (copy & 1)
    {
        ultimul = 1;
    }
    else
        ultimul = 0;
    copy >>= 1;
    if (copy & 1)
    {
        printf("%d", 1);
    }
    else
        printf("%d", 0);
    printf("%d\n", ultimul);
}






void setDBM(int bit) {
    unsigned char mask = 1 ;
    if (bit == 0) {
        mask = ~mask;
        EBI_MCR = EBI_MCR & mask;
    }
    else
        EBI_MCR = EBI_MCR | mask;


}
void setMDIS(int bit) {
    unsigned char mask = 1<<6;
    if (bit == 0) {
        mask = ~mask;
        EBI_MCR = EBI_MCR & mask;
    }
    else
        EBI_MCR = EBI_MCR | mask;
    printf("%x\n", EBI_MCR);

}

void setSIZE(int bit,int bit1) {
    unsigned long mask = 1 << 25;
    unsigned long mask1 = 1 << 24;
    if (bit == 0) {
        mask = ~mask;
        EBI_MCR = EBI_MCR & mask;
    }
    else
        EBI_MCR = EBI_MCR | mask;
    if (bit1 == 0) {
        mask1 = ~mask1;
        EBI_MCR = EBI_MCR & mask1;
    }
    else
        EBI_MCR = EBI_MCR | mask1;

}


















void getIF() {
    unsigned long copy = EBI_MCR;
    copy >>= 3;
    int final = 0;
    int p = 1;
    int ultimul;
    if (copy & 1)
    {
        ultimul = 1;
    }
    else
        ultimul = 0;
    final = ultimul * p + final;
    p = p * 10;
    copy >>= 1;
    if (copy & 1)
    {
        ultimul = 1;
    }
    else
        ultimul = 0;
    copy >>= 1;
    final = ultimul * p + final;
    p = p * 10;
    if (copy & 1)
    {
        ultimul = 1;
    }
    else
        ultimul = 0;
    copy >>= 1;
    final = ultimul * p + final;
    p = p * 10;
    if (copy & 1)
    {
        ultimul = 1;
    }
    else
        ultimul = 0;
    final = ultimul * p + final;
    p = p * 10;
    printf("%d\n", final);
}


void setIF(int bit, int bit1, int bit2, int bit3) {
    unsigned long mask = 1 << 6;
    unsigned long mask1 = 1 << 5;
    unsigned long mask2 = 1 << 4;
    unsigned long mask3 = 1 << 3;
    if (bit == 0) {
        mask = ~mask;
        EMIOS_CCR = EMIOS_CCR & mask;
    }
    else
        EMIOS_CCR = EMIOS_CCR | mask;

    if (bit1 == 0) {
        mask1 = ~mask1;
        EMIOS_CCR = EMIOS_CCR & mask1;
    }
    else
        EMIOS_CCR = EMIOS_CCR | mask1;

    if (bit2 == 0) {
        mask2 = ~mask2;
        EMIOS_CCR = EMIOS_CCR & mask2;
    }
    else
        EMIOS_CCR = EMIOS_CCR | mask2;

    if (bit3 == 0) {
        mask3 = ~mask3;
        EMIOS_CCR = EMIOS_CCR & mask3;
    }
    else
        EMIOS_CCR = EMIOS_CCR | mask3;
}