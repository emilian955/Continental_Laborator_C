#include <stdio.h>
#define EX 1
#include "Lab3.h"
#define N 5
#define M 5
#define K 20
int** aloca2d()
{
	int** matrice;
	int i;



	matrice = (int**)malloc(N * sizeof(int*));
	for (i = 0; i < N; ++i)
	{
		matrice[i] = (int*)malloc(M * sizeof(int));
}



	return matrice;
	}

void afisare(char* s[5][20]) {
	for (int i = 0; i < 5; i = i + 1) {
		printf("%s", s[i]);
		printf("\n");
	}
}

int main()
{
#if (EX==1)
	unsigned long a = 40;
	unsigned long* p = a;
	ex1(&p);
	

	
#endif


#if (EX==3)
	char* ptablou[] = {1,2,3,4,5,6,7};
	long min1 = 100;
	long max1 = 1;
	long sum1 = 1;
	calcul(ptablou, &min1, &max1, &sum1);
	
	printf("%li\n", max1);
	printf("%d\n", sum1);
	printf("%li\n", min1);
#endif


#if (EX==4)
	char* source = "Salutare";
	char destination[20];

	int num = 6;
	printf("%s", strncpy(destination, source, num));

#endif
#if (EX==2)
	unsigned short FLASH_BIUCR = 0;
	unsigned short* myFLASH_BIUCR = &FLASH_BIUCR;
	unsigned char APC = 7;
	unsigned char WWSC = 3;
	unsigned char RWSC = 7;
	ex2_init(myFLASH_BIUCR, APC, WWSC, RWSC);
	ex_afisare(myFLASH_BIUCR);

#endif

#if (EX==5)
	int (*minf)(int);
	char* ptablou[] = { 1,2,3,4,5,6,7 };
	minf = &min;
	int (*maxf)(int);
	maxf = &max;
	int (*sumf)(int);
	sumf = &sum;
	handler(max, ptablou);

#endif

#if (EX==6)

	
	//int** m = aloca2d();
	int m[5][5] = {
		{5,4,3,2,1},
		{9,8,7,6,5},
		{9,8,7,6,5},
		{9,8,7,6,5},
		{9,8,7,6,5}
	};

	int* p = m[0];
	bubbleSort(&m, 5);
	printArray(m, 5);

#endif
#if (EX==7)


	//int** m = aloca2d();
	int m[5][5] = {
		{5,4,3,2,1},
		{5,4,3,2,1},
		{5,4,3,2,1},
		{5,4,3,2,1},
		{5,4,3,2,1}
	};
	 
	int* p = m[0];
	increment(&m, 5);
	printArray(m, 5);
	printf("\n");
	swapdiag(&m, 5);
	printArray(m, 5);
#endif

#if (EX==8)
	//int** m = aloca2d();
	char m[N][K] = {
		"Salut ",
		"Suntt ",
		"Alex ",
		"elev ",
		"in Is"
	};
	char* p = m;
	for (int i = 0; i < 5; i++) {
		convert(&m[i*5]);
	}
	
#endif

	return 0;
	
}