#include <stdio.h>
#include "Lab3.h"
void ex1(unsigned long* p) {
	unsigned char* mynumber=p;
	printf("%d", *mynumber);
	printf("\n");
	for (int i = 0; i < 32; i++)
	{
		unsigned char c = ((unsigned char*)(p + i));
		if (c == '1')
			printf("1");
		else
		{
			printf("0");
		}
	}
}

void calcul(char* ptablou, long* min, long* max, long* sum) {
	//sum = sizeof(long);
	int sum1=0;
	
	for (int i = 0; i < 7; i=i+sizeof(char)) {
		printf("%d", *ptablou + i);
		int elem = *ptablou + i;
		if (elem<*min) {
			*min = elem;
		}
		if (elem > *max) {
			*max = elem;

		}
		sum1 += elem;
	}
	*sum = sum1;
	printf("\n");

	
}
int min(char* ptablou) {
	int min=100;
	for (int i = 0; i < 7; i = i + sizeof(char)) {
		int elem = *ptablou + i;
		if (elem < min) {
			min = elem;
		}
	}
	printf("%d", min);
	return min;
}
int max(char* ptablou) {
	int max = -100;
	for (int i = 0; i < 7; i = i + sizeof(char)) {
		int elem = *ptablou + i;
		if (elem > max) {
			max = elem;
		}
	}
	printf("%d", max);
	return max;
}
int handler(int (*functie)(int), unsigned long* tablou) {
	int temp;
	temp = (*functie)(tablou);
	return temp;
}

int sum(char* ptablou) {
	int max = -100;
	int sum1 = 0;
	for (int i = 0; i < 7; i = i + sizeof(char)) {
		
		int elem = *ptablou + i;
		sum1 += elem;
	}
	return sum1;
}
char* strncpy(char* destination, const char* source, size_t num)
{
	char* ptr = destination;
	while (num--)
	{
		*destination = *source;
		destination++;
		source++;
	}
	*destination = '\0';
	return ptr;
}
void ex2_init(unsigned short* FLASH_BIUCR, unsigned char APC, unsigned char WWSC, unsigned char RWSC) {

	for(int i=0;i<3;i++){
		int bit = APC & 1;
		unsigned short mask = bit << (i+13);
		if (bit == 0) {
			mask = ~mask;
			*FLASH_BIUCR = *FLASH_BIUCR & mask;
		}
		else
			*FLASH_BIUCR = *FLASH_BIUCR | mask;
		APC >> 1;

	}
	for (int i = 0; i < 2; i++) {
		int bit = WWSC & 1;
		unsigned short mask = bit << (i + 11);
		if (bit == 0) {
			mask = ~mask;
			*FLASH_BIUCR = *FLASH_BIUCR & mask;
		}
		else
			*FLASH_BIUCR = *FLASH_BIUCR | mask;
		WWSC >> 1;

	}

	for (int i = 0; i < 3; i++) {
		int bit = RWSC & 1;
		unsigned short mask = bit << (i + 8);
		if (bit == 0) {
			mask = ~mask;
			*FLASH_BIUCR = *FLASH_BIUCR & mask;
		}
		else
			*FLASH_BIUCR = *FLASH_BIUCR | mask;
		RWSC >> 1;

	}
	

}
void ex_afisare(unsigned short* FLASH_BIUCR) {
	printf("%x", *FLASH_BIUCR);
}






void swap(int* xp, int* yp)
{
	int temp = *xp;
	*xp = *yp;
	*yp = temp;
}

// A function to implement bubble sort
void bubbleSort(int* a, int num) {
	int i, j, temp;
	for (int k = 0; k < num ; k++) {
		for (i = 0; i < num ; i++){
		for (j = 0; j < num-1; j++) {
			
			if (*((a + i*5) +j) > *((a + i * 5) + j + 1)) {
				swap((a + i * 5) + j, (a + i * 5) + j+1);
			}
							
		}}
	}
}
void printArray(int a[], int num)
{
	int i,j;
	for (i = 0; i < num; i++) {
		for (j = 0; j < num; j++)
			printf("%d ", *((a + i * 5) + j));
		printf("\n");
	}
}
void increment(int* arr, int n)
{
	int i, j;
		for (j = 0; j < n; j++)
			*((arr + j * 5) + j) += 1;
}
void swapdiag(int* a, int num)
{
	int i, j;
	for (i = 0; i < num; i++) {
		for (j = i; j < num; j++)
			swap((a + i * 5) + j, (a + j * 5) + i);
	}
}
void convert(char* str) {

	char c_to_search[5] = "salut";
	for (int j = 0; j < 20; j++)
	{

		//char *text[5]= &(str) + j * 5;
		//functia de cautare intr-un sir de caractere
		int pos_search = 0;
		int pos_text = 0;
		int len_search = 4;
		int len_text = 67;
		for (pos_text = 0; pos_text < len_text - len_search; ++pos_text)
		{
			if (str[pos_text] >= 65 && str[pos_text] <= 90)
				str[pos_text] = str[pos_text] + 32;
			if (str[pos_text] == c_to_search[pos_search])
			{
				++pos_search;
				if (pos_search == len_search)
				{
					// match
					printf("match from %d to %d\n", pos_text - len_search+1, pos_text+1);
					return 1;
				}
			}
			else
			{
				pos_text -= pos_search;
				pos_search = 0;
			}
		}
		// no match


	}
}