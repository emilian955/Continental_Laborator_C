#include <stdio.h>
#define setbit(byte,nbit)   ((byte) |=  (1<<(nbit)))
#define clearbit(byte,nbit) ((byte) &= ~(1<<(nbit)))
#define NUMAR 6


#define LUNGIME_TABLOU 8
unsigned long tablouIntervale[LUNGIME_TABLOU] = { 5,20,50,90,100,130,139,160 };
#define LUNGIME_PP 3
#define LUNGIME_NPP 3
#define LUNGIME_NN 3


int tab_nrPrimePozitive[LUNGIME_PP]; /* tablou de numere prime pozitive */
int tab_nrNonPrimePozitive[LUNGIME_NPP]; /* tablou de numere pozitive care nu sunt prime */
int tab_nrNegative[LUNGIME_NN]; /* tablou de numere negative */

int prim(int n) {
    int  i, m = 0, flag = 0;
    m = n / 2;
    for (i = 2; i <= m; i++)
    {
        if (n % i == 0)
        {
            return 0;
            flag = 1;
            break;
        }
    }
    if (flag == 0)
        return 1;
}

int fibbonacci(int n) {
    int i;
    int t1 = 0, t2 = 1;
    int nextTerm = t1 + t2;
    for (i = 3; i <= n; ++i) {
        printf("%d, ", nextTerm);
        t1 = t2;
        t2 = nextTerm;
        nextTerm = t1 + t2;
    }
    return nextTerm;
}
char ascii(int number) {
    return '0' + number;
}
void inttoascii(int N) {
    char ascii[20];
    while (N > 0) {
        int d = N % 10;
        printf("0x%d ", 48 + d);
        N = N / 10;
    }

}
void partitie(int v[8]) {
    int contorPP = 0, contorNPP = 0, contorNN = 0;
    for (int i = 0; i < 8; i++) {
        if ((contorPP == LUNGIME_PP) || (contorNN == LUNGIME_NN) || (contorNPP == LUNGIME_NPP)) {
            printf("Unul din tablouri s-a umplut");
            return 0;
        }
        if (v[i] < 0)
        {
            tab_nrNegative[contorNN] = v[i];
            contorNN++;
        }
        if (prim(v[i]) && v[i] > 0) {
            tab_nrPrimePozitive[contorPP] = v[i];
            contorPP++;

        }
        if (prim(v[i]) == 0 && v[i] > 0) {
            tab_nrNonPrimePozitive[contorNPP] = v[i];
            contorNPP++;
        }
    }
}




void convertire(unsigned long ex1) {
    int binaryNum[32];
    int aux;
    int raspuns = 0;
    int p = 1;

    while (ex1 > 0) {
        aux = ex1 % 2;
        ex1 = ex1 / 2;
        raspuns = aux * p + raspuns;
        p *= 10;
    }
    printf("%lu", raspuns);
}


unsigned char reverse(unsigned char ex1) {
    int binaryNum[32];
    int aux;
    int raspuns = 0;
    int p = 1;
    char r;

    while (ex1 > 0) {
        aux = ex1 % 2;
        ex1 = ex1 / 2;
        raspuns = raspuns * 10 + aux;

    }
    char c = raspuns;
    printf("%c", c);
}



int ex4(int val, unsigned long v[LUNGIME_TABLOU]) {
    for (int i = 0; i < LUNGIME_TABLOU; i++) {
        if (val < v[i]) {
            return i;
        }
    }
    return LUNGIME_TABLOU;
}
//int main() {
//    int ex1 = 6;
//    setbit(ex1, 0);
//    printf("%d\n", ex1);
//    clearbit(ex1, 0);
//    printf("%d\n", ex1);
//    convertire(NUMAR);
//
//    //ex1 = reverse(6);
//    printf("EX4\n");
//
//    printf("%d\n", ex4(188, tablouIntervale));
//
//
//    int vector[8] = { 23,1,-2,7,6,8,-4,13 };
//    inttoascii(25);
//    return 0;
//}
