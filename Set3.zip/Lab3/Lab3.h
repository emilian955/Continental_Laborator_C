#pragma once
void ex1(unsigned long* p);
void calcul(char* ptablou, long* min, long* max, long* sum);
char* strncpy(char* destination, const char* source, size_t num);
void ex2_init(unsigned short* FLASH_BIUCR, unsigned char APC, unsigned char WWSC, unsigned char RWSC);
void ex_afisare(unsigned short* FLASH_BIUCR);
int min(char* ptablou);
int max(char* ptablou);
int sum(char* ptablou);
int handler(int (*functie)(int), unsigned long* tablou); 
void swap(int* xp, int* yp);
void bubbleSort(int* a, int num);
void printArray(int arr[], int size);
void increment(int* arr, int n);
void swapdiag(int* arr, int n);
