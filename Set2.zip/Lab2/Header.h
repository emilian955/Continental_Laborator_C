#pragma once
#define setbit(byte,nbit)   ((byte) |=  (1<<(nbit)))
#define clearbit(byte,nbit) ((byte) &= ~(1<<(nbit)))
#define NUMAR 6


#define LUNGIME_TABLOU 8

#define LUNGIME_PP 3
#define LUNGIME_NPP 3
#define LUNGIME_NN 3


int tab_nrPrimePozitive[LUNGIME_PP]; /* tablou de numere prime pozitive */
int tab_nrNonPrimePozitive[LUNGIME_NPP]; /* tablou de numere pozitive care nu sunt prime */
int tab_nrNegative[LUNGIME_NN]; /* tablou de numere negative */



#define MN 1 /* MAN */
#define RT 2 /* Renault */
#define VT 3 /* Volvo */
#define MT 4 /* Mack */
#define HighLine 1
#define BasicLine 2

//A-nimic
//#define INSBrand MT
//#define INSVar HighLine



//B)-1,2,3
//#define INSBrand RT
//#define INSVar BasicLine



//C) -1,2
//#define INSBrand VT
//#define INSVar BasicLine

//D)-1,2
//#define INSBrand VT
//#define INSVar HighLine
#if( (INSBrand == VT) || (INSBrand == RT) || (INSBrand == MN))
static void LEDC__vSwitchTachoRedLeds(uint8 u8RangeLow, uint8 u8RangeHigh); /*1*/
static void LEDC__vSwitchTachoGreenLeds(uint8 u8RangeLow, uint8 u8RangeHigh); /*2*/
#if ((INSBrand == RT) || (INSBrand == MN))
static void LEDC__vSwitchTachoBlueLeds(uint8 u8RangeLow, uint8 u8RangeHigh); /*3*/
#endif
#if ( ((INSBrand == VT) &amp;&amp; (INSVar == HighLine)) || (INSBrand == MN))
static void LEDC__vSwitchACCLeds(uint8 u8RangeLow, uint8 u8RangeHigh); /*4*/
#endif
#endif

//#define INSBrand MT
//#define INSVar HighLine







int prim(int n);
int fibbonacci(int n);
char ascii(int number);
void inttoascii(int N);
void partitie(int v[8]);
void convertire(unsigned long ex1);
unsigned char reverse(unsigned char ex1);
int ex4(int val, unsigned long v[LUNGIME_TABLOU]);
int CautareBinara(int x);