#include <stdio.h>
#include "Header.h"

int prim(int n) {
    int  i, m = 0, flag = 0;
    m = n / 2;
    for (i = 2; i <= m; i++)
    {
        if (n % i == 0)
        {
            return 0;
            flag = 1;
            break;
        }
    }
    if (flag == 0)
        return 1;
}

int fibbonacci(int n) {
    int i;
    int t1 = 0, t2 = 1;
    int nextTerm = t1 + t2;
    for (i = 3; i <= n+2; ++i) {
        printf("%d, ", nextTerm);
        t1 = t2;
        t2 = nextTerm;
        nextTerm = t1 + t2;
    }
    return nextTerm;
}
char ascii(int number) {
    return '0' + number;
}
void inttoascii(int N) {
    char ascii[20];
    while (N > 0) {
        int d = N % 10;
        printf("0x%d ", 48 + d);
        N = N / 10;
    }

}
void partitie(int v[8]) {
    int contorPP = 0, contorNPP = 0, contorNN = 0;
    for (int i = 0; i < 8; i++) {
        if ((contorNPP == LUNGIME_NPP)) {
            printf("NPP s-a umplut");
            return 0;
        }


        if ((contorPP == LUNGIME_PP) ) {
            printf("Prime Pozitive s-a umplut");
            return 0;
        }
        if (contorNN == LUNGIME_NN) {
            printf("NN s-a umplut");
            return 0;
        }






        if (v[i] < 0)
        {
            tab_nrNegative[contorNN] = v[i];
            contorNN++;
        }
        if (prim(v[i]) && v[i] > 0) {
            tab_nrPrimePozitive[contorPP] = v[i];
            contorPP++;

        }
        if (prim(v[i]) == 0 && v[i] > 0) {
            tab_nrNonPrimePozitive[contorNPP] = v[i];
            contorNPP++;
        }
    }
}




void convertire(unsigned long ex1) {
    int binaryNum[32];
    int aux;
    int raspuns = 0;
    int p = 1;

    while (ex1 > 0) {
        aux = ex1 % 2;
        ex1 = ex1 / 2;
        raspuns = aux * p + raspuns;
        p *= 10;
    }
    printf("%lu\n", raspuns);
}


unsigned char reverse(unsigned char ex1) {
    convertire(ex1);
    int binaryNum[32];
    int aux;
    int raspuns = 0;
    int p = 1;
    char r;

    while (ex1 > 0) {
        aux = ex1 % 2;
        ex1 = ex1 / 2;
        raspuns = raspuns * 10 + aux;

    }
    char c = raspuns;
    printf("%d",raspuns);
}



int ex4(int val, unsigned long v[LUNGIME_TABLOU]) {
    for (int i = 0; i < LUNGIME_TABLOU; i++) {
        if (val < v[i]) {
            return i;
        }
    }
    return LUNGIME_TABLOU;
}
const int ex10 = 9;
int ex9v[10] = { 9,8,7,6,5,4,3,2,1,0 };

int CautareBinara(int x)
{
    int Sol = -1, Left = 0, Right = ex10;
    while (Left <= Right)
    {
        int Mid = (Left + Right) / 2;
        if (ex9v[Mid] == x)
        {
            Sol = Mid;
            break;
        }
        if (ex9v[Mid] > x)
            Right = Mid - 1;
        if (ex9v[Mid] < x)
            Left = Mid + 1;
    }
    return Sol;
}

void ex9() {
    int nr_de_cautat = 5;
    printf("%d",CautareBinara(nr_de_cautat));
    for (int i = 0; i <= ex10;i++) {
        if (ex9v[i] == nr_de_cautat) {
            printf("\n%d", i);
        }
    }
}