#include <stdio.h>
#include "Header.h"
#define EX 9
unsigned long tablouIntervale[LUNGIME_TABLOU] = { 5,20,50,90,100,130,139,160 };


int main() {

#if (EX==1)
  convertire(6);
#endif

#if (EX==2)
   int ex1 = 6;
   setbit(ex1, 0);
   printf("%d\n", ex1);
   clearbit(ex1, 0);
   printf("%d\n", ex1);
#endif


#if (EX==3)
   reverse(171);
#endif
  

#if (EX==4)
   printf("%d\n", ex4(188, tablouIntervale));
#endif

#if (EX==5)
   int vector[8] = { 23,1,-2,7,6,8,-4,13 };
   partitie(vector);
#endif

#if (EX==7)
   inttoascii(25);
#endif
#if (EX==8)
   fibbonacci(10);
#endif

#if (EX==9)
   ex9();
#endif
    return 0;
}
